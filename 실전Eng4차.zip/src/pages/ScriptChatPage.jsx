import React from 'react';
import SCLayout from "../components/scriptChat/SCLayout";


const ScriptChatPage = () => {
  return (
    <div>
    <SCLayout />
    </div>
  )
}

export default ScriptChatPage;