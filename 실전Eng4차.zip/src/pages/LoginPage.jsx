import React from 'react'
import LoginImg from '../components/login/LoginImg'

const LoginPage = () => {
  return (
    <>
    <LoginImg>
    </LoginImg>
    </>
  )
}

export default LoginPage

