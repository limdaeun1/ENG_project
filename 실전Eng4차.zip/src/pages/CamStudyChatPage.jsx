import React from 'react';
import CSLayout from "../components/camstudyChat/CSLayout";

const CamStudyChatPage = () => {
  return (
    <div>
      <CSLayout/>
    </div>
  )
}

export default CamStudyChatPage;